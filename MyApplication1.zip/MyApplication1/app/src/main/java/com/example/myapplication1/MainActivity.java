package com.example.myapplication1;

import android.os.Bundle;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


import android.content.Intent;

import android.view.View;
import android.widget.Button;
import android.widget.Spinner;


public class MainActivity extends AppCompatActivity {

    private EditText editTextNom, editTextEmail, editTextPhone, editTextAdresse;
    private Spinner villes;
    private Button buttonEnvoyer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextNom = findViewById(R.id.editTextNom);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPhone = findViewById(R.id.editTextPhone);
        editTextAdresse = findViewById(R.id.editTextAdresse);
        villes = findViewById(R.id.villes);
        buttonEnvoyer = findViewById(R.id.buttonEnvoyer);

        buttonEnvoyer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SummaryActivity.class);
                intent.putExtra("nom", editTextNom.getText().toString());
                intent.putExtra("email", editTextEmail.getText().toString());
                intent.putExtra("phone", editTextPhone.getText().toString());
                intent.putExtra("adresse", editTextAdresse.getText().toString());
                intent.putExtra("ville", villes.getSelectedItem().toString());
                startActivity(intent);
            }
        });
    }
}